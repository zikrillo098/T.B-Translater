from telebot.types import ReplyKeyboardMarkup, KeyboardButton  # Контэйенер и сами кнопки
from configs import LANGUAGES  # Это словарик


def generate_languages():
    markup = ReplyKeyboardMarkup(row_width=2, one_time_keyboard=True)  # row_width=3 - сколько кнопок в одной строке
    #  one_time_keyboard=True -- Спустит кнопки вниз
    buttons = []
    for lang in LANGUAGES.values():  # Проходимся по значениям
        btn = KeyboardButton(text=lang)
        buttons.append(btn)

    markup.add(*buttons)  # add - принимает только объекты а buttons это список а * распоковывает ее
    # Например: list1 = [11, 'gfdf', 21]
    # output: [11, 'gfdf', 21] If we print(list1)
    # output: 11 gfdf, 21 if we print(*list1)

    return markup  # Функция возврашяет markup
