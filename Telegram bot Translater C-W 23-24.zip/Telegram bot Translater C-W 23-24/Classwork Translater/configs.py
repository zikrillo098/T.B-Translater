TOKEN = '5196354614:AAHAkMzjic7YMpojYe3kageRmKS7suX6X8k'

LANGUAGES = {
    'en': 'Английский',
    'de': 'Немецкий',
    'uz': 'Узбекский',
    'es': 'Испанский',
    'ru': 'Русский',
    'ar': 'Арабский'
}


# Функция по получению ключа по значению
def get_key(value):
    for k, v in LANGUAGES.items():  # Проходимся по словорю, LANGUAGES.items() - Будет возврашять('ar': 'Арабский')
        if v == value:  # v - это значение, Если наще значение равно значению value то верни ключ
            return k
