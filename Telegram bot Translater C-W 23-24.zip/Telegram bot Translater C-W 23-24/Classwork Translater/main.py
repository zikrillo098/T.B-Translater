# В первую очередь поднимаем Виртуальное окружение
# Скачиваем библиотеку "pytelegrambotapi"
# После чего запускаем BotFather с галочкой
# В "configs" создаем переменную TOKEN с нашим токеном "TOKEN = '5196354614:AAHAkMzjic7YMpojYe3kageRmKS7suX6X8k'"
# pip install googletrans --- качаем библиотеку

# @TODO Начали суету

from telebot import TeleBot
from configs import *
from keyboards import *
from telebot.types import Message  # Что бы функция могла принимать только сообщения
import sqlite3
from googletrans import Translator

bot = TeleBot(TOKEN, parse_mode='HTML')  # Регистрируем нашего БОТА


@bot.message_handler(commands=['start', 'help', 'about', 'history'])
# Реакции у функции пишуться через:
# "@bot.message_handler(реакция будет иммено на что[комманды отправляються в ввиде списка])"
def command_start(message: Message):  # Реакция на первую комманду -- "(message: Message) Функция жди только сообщение"
    chat_id = message.chat.id  # ID Пользователя который запустил бот
    user_name = message.chat.first_name  # Имя пользователя
    if message.text == '/start':  # если сообение "/star" - То отправь сообьшение
        bot.send_message(chat_id, f'''Добро пожаловать {user_name}!
Наш бот супер быстрый и надеямся что он принесет вам пользу''')  # (1.Кому, 2.Что отправить)
        start_translate(message)  # Функция которая с низу Запускаеться
    if message.text == '/help':
        bot.send_message(chat_id, f'''{user_name}! Если у вас есть предложения или же у вас что-то не работает!
Создатель Бота: @Zikrillo098 Можете спокойно написать)''')
    if message.text == '/about':
        bot.send_message(chat_id, f'''{user_name} Спасибо что интересуетесь нашим ботом
Краткая история:
--- Я решил создать этого бота ради отца)''')
    if message.text == '/history':
        return_user_history(message)


def return_user_history(message: Message):
    chat_id = message.chat.id
    db = sqlite3.connect('database.db')
    cursor = db.cursor()

    cursor.execute('''
    SELECT from_lang, to_lang, original_text, translated_text FROM history
    WHERE telegram_id = ?
    ''', (chat_id,))
    history = cursor.fetchall()
    history = history[::-1]  # В базу данных записываеться от старого к новому а мы должны сделать наооборот
    print(history)
    for from_lang, to_lang, original_text, translated_text in \
            history[:10]:  # В базу данных записываеться, [:10]: ограничили до последних 10 сообщений
        bot.send_message(chat_id, f'''Вы переводили: {from_lang}
На язык: {to_lang}
Текст сообщения: {original_text}
Бот перевел: {translated_text}''')
        db.close()


def start_translate(message: Message):
    chat_id = message.chat.id
    user_name = message.chat.first_name
    src = bot.send_message(chat_id, f'''{user_name} 
Выберите с какого языка будете переводить текс: ''', reply_markup=generate_languages())
    bot.register_next_step_handler(src,
                                   second_language)  # Бот жди следующий шаг и сразу запускай функцию second_language


@bot.message_handler(
    func=lambda message: message.text in LANGUAGES.values())  # То есть текст должен быть в наших значениях LANGUAGES
def second_language(message):
    chat_id = message.chat.id
    user_name = message.chat.first_name
    src = message.text  # созраняем сообшение
    if src in LANGUAGES.values():
        dest = bot.send_message(chat_id, f''' {user_name} вы выбрали: {src}
Выберите на какой язык хотите перевести текст текс: ''', reply_markup=generate_languages())
        bot.register_next_step_handler(dest, give_me_text, src)
    # Бот жди следуюший шаг после сообщения dest отправь функцию give_me_text, src - сохранит все
    else:
        command_start(message)
        return  # Выход из функции


@bot.message_handler(
    func=lambda message: message.text in LANGUAGES.values())  # То есть текст должен быть в наших значениях LANGUAGES
def give_me_text(message: Message, src):
    chat_id = message.chat.id
    user_name = message.chat.first_name
    dest = message.text
    if dest in LANGUAGES.values():
        text = bot.send_message(chat_id, f''' {user_name} вы выбрали: {dest}
Введиите слово или текст который хотите перевести:''')
        bot.register_next_step_handler(text, translate, src, dest)
    else:
        command_start(message)
        return  # Выход из функции


def translate(message: Message, src, dest):
    chat_id = message.chat.id
    origin = message.text
    translator = Translator()
    tr_text = translator.translate(text=origin, src=get_key(src), dest=get_key(dest))  # Получаем переведенный текст
    bot.send_message(chat_id, f'<b>{tr_text.text}</b'
                              f'>')
    db = sqlite3.connect('database.db')
    cursor = db.cursor()

    cursor.execute('''
    INSERT INTO history(telegram_id, from_lang, to_lang, original_text, translated_text)
    VALUES(?,?,?,?,?)
    ''', (chat_id, src, dest, origin, tr_text.text))
    db.commit()
    db.close()

    start_translate(message)


bot.polling(non_stop=True)  # То есть не когда не останавливайся
