import sqlite3

db = sqlite3.connect('database.db')
cursor = db.cursor()  # cursor - это объект через которого вы будете выполнять действие как мышка

cursor.execute('''
    CREATE TABLE IF NOT EXISTS history(
        history_id INTEGER PRIMARY KEY AUTOINCREMENT, 
        telegram_id BIGINT,
        from_lang TEXT,
        to_lang TEXT,
        original_text TEXT,
        translated_text TEXT
    )
''')
db.commit()  # Подтверждает отправку в базу данных
db.close()
